<div class="wrapper">
        <div class="full-block">
            <div class="home-main-cats">
                <div class="main-cat-block block-1">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/autos/n-0-1-1">
							<i class="flaticon-transport-1"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/autos/n-0-1-1">
							Autos							</a>
                    </div>
                </div>
                <div class="main-cat-block block-2">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/bar-restaurant/n-0-29-1">
							<i class="flaticon-restaurant"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/bar-restaurant/n-0-29-1">
							Bar & Restaurant							</a>
                    </div>
                </div>
                <div class="main-cat-block block-3">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/computer/n-0-74-1">
							<i class="flaticon-computer"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/computer/n-0-74-1">
							Computer							</a>
                    </div>
                </div>
                <div class="main-cat-block block-4">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/diet-health/n-0-83-1">
							<i class="flaticon-heart-beats"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/diet-health/n-0-83-1">
							Diet & Health							</a>
                    </div>
                </div>
                <div class="main-cat-block block-5">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/entertainment/n-0-99-1">
							<i class="flaticon-tickets"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/entertainment/n-0-99-1">
							Entertainment							</a>
                    </div>
                </div>
                <div class="main-cat-block block-6">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/fitness/n-0-133-1">
							<i class="flaticon-weights"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/fitness/n-0-133-1">
							Fitness							</a>
                    </div>
                </div>
                <div class="main-cat-block block-7">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/home/n-0-144-1">
							<i class="flaticon-paint"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/home/n-0-144-1">
							Home							</a>
                    </div>
                </div>
                <div class="main-cat-block block-8">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/insurance/n-0-176-1">
							<i class="flaticon-home"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/insurance/n-0-176-1">
							Insurance							</a>
                    </div>
                </div>
                <div class="main-cat-block block-9">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/stores/n-0-218-1">
							<i class="flaticon-commerce"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/stores/n-0-218-1">
							Stores							</a>
                    </div>
                </div>
                <div class="main-cat-block block-10">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/pet-animal/n-0-300-1">
							<i class="flaticon-animals"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/pet-animal/n-0-300-1">
							Pet & Animal							</a>
                    </div>
                </div>
                <div class="main-cat-block block-11">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/services/n-0-317-1">
							<i class="flaticon-cogwheel"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/services/n-0-317-1">
							Services							</a>
                    </div>
                </div>
                <div class="main-cat-block block-12">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/real-estate/n-0-345-1">
							<i class="flaticon-building"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/real-estate/n-0-345-1">
							Real Estate							</a>
                    </div>
                </div>
                <div class="main-cat-block block-13">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/education/n-0-390-1">
							<i class="flaticon-book"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/education/n-0-390-1">
							Education							</a>
                    </div>
                </div>
                <div class="main-cat-block block-14">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/shopping/n-0-420-1">
							<i class="flaticon-commerce-1"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/shopping/n-0-420-1">
							Shopping							</a>
                    </div>
                </div>
                <div class="main-cat-block block-15">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/travel/n-0-452-1">
							<i class="flaticon-transport"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/travel/n-0-452-1">
							Travel							</a>
                    </div>
                </div>
                <div class="main-cat-block block-16">
                    <div class="main-cat-icon">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/beauty/n-0-510-1">
							<i class="flaticon-beauty"></i>							</a>
                    </div>
                    <div class="main-cat-name">
                        <a href="http://codebasedev.com/directoryapp/directoryapp_108/us/list/beauty/n-0-510-1">
							Beauty							</a>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <!-- home-main-categories -->
        </div>
        <!-- .full-block -->

        <h2>Featured Businesses</h2>

        <div class="home-trending-venues">
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/san-francisco/place/2/piccolo-petes-cafe" title="Piccolo Petes Cafe">
                    <div class="featured-item-pic" id="2">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/16.04.30.18.42-1462056141.0604-74271483.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="5.00">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>Piccolo Petes Cafe</h3>
                </a>

                <div class="user-card">
                    <div class="user-pic">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/profile_pic_thumb/1/18.jpg" />
                    </div>

                    <div class="user-name">
                        <h3>Victoria S.</h3>
                    </div>
                </div>
                <!-- .user-card -->

                <div class="featured-item-description">
                    The Spicy Mexican Mocha is soooo good! I do not <a href="http://codebasedev.com/directoryapp/directoryapp_108/san-francisco/place/2/piccolo-petes-cafe"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/manzano/place/3/arsicault-bakery" title="Arsicault Bakery">
                    <div class="featured-item-pic" id="3">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/16.04.30.18.52-1462056728.5069-11776224.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="5.00">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>Arsicault Bakery</h3>
                </a>

                <div class="user-card">
                    <div class="user-pic">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/profile_pic_thumb/1/2.jpg" />
                    </div>

                    <div class="user-name">
                        <h3>James G.</h3>
                    </div>
                </div>
                <!-- .user-card -->

                <div class="featured-item-description">
                    Had a craving for croissants after returning from France. I'm <a href="http://codebasedev.com/directoryapp/directoryapp_108/manzano/place/3/arsicault-bakery"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/chicago/place/4/the-health-insurance-shoppe" title="The Health Insurance Shoppe">
                    <div class="featured-item-pic" id="4">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/16.04.30.19.38-1462059512.4712-80567835.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="5.00">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>The Health Insurance Shoppe</h3>
                </a>

                <div class="user-card">
                    <div class="user-pic">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/profile_pic_thumb/1/11.jpg" />
                    </div>

                    <div class="user-name">
                        <h3>Marilyn T.</h3>
                    </div>
                </div>
                <!-- .user-card -->

                <div class="featured-item-description">
                    Today I called the Health Insurance Shoppe because I'm dealing <a href="http://codebasedev.com/directoryapp/directoryapp_108/chicago/place/4/the-health-insurance-shoppe"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/miami/place/5/masterclass-automotive" title="MasterClass Automotive">
                    <div class="featured-item-pic" id="5">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/16.04.30.19.16-1462058218.4485-96948016.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="5.00">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>MasterClass Automotive</h3>
                </a>

                <div class="user-card">
                    <div class="user-pic">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/profile_pic_thumb/1/3.jpg" />
                    </div>

                    <div class="user-name">
                        <h3>Glenn H.</h3>
                    </div>
                </div>
                <!-- .user-card -->

                <div class="featured-item-description">
                    Great bmw service. Ronald explains everything that is done to <a href="http://codebasedev.com/directoryapp/directoryapp_108/miami/place/5/masterclass-automotive"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/los-angeles/place/6/garage-door-doctor" title="Garage Door Doctor">
                    <div class="featured-item-pic" id="6">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/16.04.30.19.34-1462059285.9823-23553722.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="5.00">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>Garage Door Doctor</h3>
                </a>

                <div class="user-card">
                    <div class="user-pic">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/profile_pic_thumb/1/14.jpg" />
                    </div>

                    <div class="user-name">
                        <h3>Melinda V.</h3>
                    </div>
                </div>
                <!-- .user-card -->

                <div class="featured-item-description">
                    My garage door failed to work last night. I <a href="http://codebasedev.com/directoryapp/directoryapp_108/los-angeles/place/6/garage-door-doctor"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/miami/place/7/blackbird-ordinary" title="Blackbird Ordinary">
                    <div class="featured-item-pic" id="7">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/16.04.23.20.33-1461468812.5794-27985890.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="4.00">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>Blackbird Ordinary</h3>
                </a>

                <div class="user-card">
                    <div class="user-pic">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/profile_pic_thumb/1/12.jpg" />
                    </div>

                    <div class="user-name">
                        <h3>Oscar F.</h3>
                    </div>
                </div>
                <!-- .user-card -->

                <div class="featured-item-description">
                    Pro: very friendly and warm service. And it's a Michelan <a href="http://codebasedev.com/directoryapp/directoryapp_108/miami/place/7/blackbird-ordinary"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/san-francisco/place/161/earthbody" title="Earthbody">
                    <div class="featured-item-pic" id="161">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/17.03.14.13.37-1489523866.2663-93239468.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>Earthbody</h3>
                </a>

                <div class="featured-item-description">
                    Specialties We work structurally to release habitual patterns deep in the <a href="http://codebasedev.com/directoryapp/directoryapp_108/san-francisco/place/161/earthbody"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/san-francisco/place/162/veer-amp-wander" title="Veer &amp; Wander">
                    <div class="featured-item-pic" id="162">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/17.03.14.13.58-1489525106.3351-1810999.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>Veer &amp; Wander</h3>
                </a>

                <div class="featured-item-description">
                    Specialties Offering cuts, color, blowouts and a lot more. Our creative <a href="http://codebasedev.com/directoryapp/directoryapp_108/san-francisco/place/162/veer-amp-wander"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/los-angeles/place/163/the-phoenix" title="The Phoenix">
                    <div class="featured-item-pic" id="163">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/17.03.14.15.20-1489530032.762-7637380.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>The Phoenix</h3>
                </a>

                <div class="featured-item-description">
                    Established in 2016. The Phoenix is poised for its third act. <a href="http://codebasedev.com/directoryapp/directoryapp_108/los-angeles/place/163/the-phoenix"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/los-angeles/place/164/the-spare-room-bar" title="The Spare Room Bar">
                    <div class="featured-item-pic" id="164">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/17.03.14.15.41-1489531307.7246-22233134.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>The Spare Room Bar</h3>
                </a>

                <div class="featured-item-description">
                    Not much you can complain about when a place looks <a href="http://codebasedev.com/directoryapp/directoryapp_108/los-angeles/place/164/the-spare-room-bar"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/new-york/place/165/the-mysterious-bookshop" title="The Mysterious Bookshop">
                    <div class="featured-item-pic" id="165">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/17.03.14.17.39-1489538372.5518-28557284.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>The Mysterious Bookshop</h3>
                </a>

                <div class="featured-item-description">
                    Mystery fiction, rare and collectable titles, limited deluxe editions from <a href="http://codebasedev.com/directoryapp/directoryapp_108/new-york/place/165/the-mysterious-bookshop"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/new-york/place/166/auh2o" title="AuH2O">
                    <div class="featured-item-pic" id="166">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/17.03.14.17.46-1489538810.6712-98179913.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>AuH2O</h3>
                </a>

                <div class="featured-item-description">
                    AuH2O is a curated thrift and vintage boutique. Our shop <a href="http://codebasedev.com/directoryapp/directoryapp_108/new-york/place/166/auh2o"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="featured-item">
                <a href="http://codebasedev.com/directoryapp/directoryapp_108/new-york/place/167/the-chemist-shop" title="The Chemist Shop">
                    <div class="featured-item-pic" id="167">
                        <img src="http://codebasedev.com/directoryapp/directoryapp_108/place_pic_full/1/17.03.14.17.54-1489539278.7933-85607920.jpg">
                    </div>
                    <!-- .featured-item-pic -->

                    <div class="featured-item-rating" data-rating="">
                        <!-- raty plugin placeholder -->
                    </div>

                    <h3>The Chemist Shop</h3>
                </a>

                <div class="featured-item-description">
                    Compounding, Hormone Replacement Therapy, Specialty Drugs, and Disease Management. <a href="http://codebasedev.com/directoryapp/directoryapp_108/new-york/place/167/the-chemist-shop"><strong style="font-size: 1.2rem;">Continue reading</strong></a>
                </div>
                <!-- .featured-item-desc -->
            </div>
            <!-- .featured-item  -->
            <div class="clear"></div>
        </div>
        <!-- .home-trending-venues -->

        <h2>Popular Cities</h2>

        <div class="home-popular-cities full-block">
            <ul>
                <li><a href="http://codebasedev.com/directoryapp/directoryapp_108/austin/list/all-categories/c-24535-0-1">Austin</a></li>
                <li><a href="http://codebasedev.com/directoryapp/directoryapp_108/chicago/list/all-categories/c-6275-0-1">Chicago</a></li>
                <li><a href="http://codebasedev.com/directoryapp/directoryapp_108/miami/list/all-categories/c-4628-0-1">Miami</a></li>
                <li><a href="http://codebasedev.com/directoryapp/directoryapp_108/new-york/list/all-categories/c-17526-0-1">New York</a></li>
                <li><a href="http://codebasedev.com/directoryapp/directoryapp_108/san-francisco/list/all-categories/c-3115-0-1">San Francisco</a></li>
                <li><a href="http://codebasedev.com/directoryapp/directoryapp_108/washington/list/all-categories/c-4121-0-1">Washington</a></li>
            </ul>
            <div class="clear"></div>
        </div>
    </div>